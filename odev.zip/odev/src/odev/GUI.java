package odev;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GUI extends JFrame implements ActionListener {

    private static JButton getSource() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    JFrame jf;
    JPanel jp;
    JButton b, b1;
    JTextField tf, tf1;
    JLabel jl, jl1;

    public GUI() {
        jl = new JLabel("Kullanici adi:");
        jl.setBounds(30, 30, 100, 30);
        jl1 = new JLabel("Şifre:");
        jl1.setBounds(30, 60, 100, 30);

        tf = new JTextField();
        tf.setBounds(110, 30, 200, 30);
        tf1 = new JTextField();
        tf1.setBounds(110, 60, 200, 30);

        b = new JButton("Listele");
        b.setBounds(430, 150, 100, 30);
        b1 = new JButton("Kaydet");
        b1.setBounds(300, 150, 100, 30);

         b.addActionListener(this);
         b1.addActionListener(this);

        jp = new JPanel();
        jp.setLayout(null);
        jp.add(b);
        jp.add(b1);
        jp.add(jl);
        jp.add(jl1);
        jp.add(tf);
        jp.add(tf1);
        add(jp);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        dosya d = new dosya();

        String kadi = tf.getText();
        String sifre = tf1.getText();

        if (GUI.getSource() == b1) {
            try {
                d.yazma(kadi, sifre);
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (GUI.getSource() == b) {
            try {
                d.okuma();
            } catch(IOException ex)  {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

}
