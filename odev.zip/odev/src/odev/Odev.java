package odev;


import javax.swing.JFrame;


public class Odev {
    
    public static void main(String[] args) {
        GUI g = new GUI();
        g.setSize(800,400);      
        g.setTitle("Kayit Ekrani");
        g.setVisible(true);
        g.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }   
}
