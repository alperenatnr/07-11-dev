
package odev;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class dosya {
    
    public void yazma(String kadi,String sifre) throws IOException{
        File dosya = new File("dosya.txt");
        
        FileWriter fw = new FileWriter(dosya,true);
        try(BufferedWriter bw = new BufferedWriter(fw)){
            bw.append(kadi + " ");
            bw.append(sifre + " \n");
            System.out.println("");
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    
    public void okuma() throws FileNotFoundException, IOException{
        File dosya = new File("dosya.txt");
        
        FileReader fr = new FileReader(dosya);
        String str;
        
        System.out.println("List:");
        
        try(BufferedReader br = new BufferedReader(fr)){
            while((str=br.readLine())  !=  null){
                System.out.println("str");
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
}
